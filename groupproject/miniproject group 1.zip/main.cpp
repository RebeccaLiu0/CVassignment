//Computer Vision 159731 2018 Mini project
//Designed by: Jerry Wang(Student ID: 02304430) and Rebecca Liu(Student ID:17238744)
//Date: 18/Apr/2018 - 19/June/2018
//Program can be compiled as below:
//g++ -std=c++11 -o main main.cpp `pkg-config --cflags --libs opencv`
//or use make with makefile shown below
//   CC = g++
//   CFLAGS = -std=c++11
//   PROG = main
//   SRCS = $(PROG).cpp
//   PROGS = ./$(PROG)
//   OBJS=$(PROG).o
//   OPENCV = `pkg-config opencv --cflags --libs`
//   LIBS = $(OPENCV)
//   $(PROG):$(SRCS)
//      $(CC) $(CFLAGS) -o $(PROG) $(SRCS) $(LIBS)
//Usage:
//for image:         ./main imagefile  [-LBP] (default -HAAR)
//for video file:    ./main videofile  [-LBP] (default -HAAR)
//for video camera:  ./main [-LBP] (default -HAAR)

#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <dirent.h>
#include <unistd.h>

#include <iostream>
#include <stdio.h>
#include <chrono>

using namespace std;
using namespace cv;
using namespace chrono;

/** Function Headers */
void detectAndDisplay(Mat frame);
void Test(const char *imgdir);

/** Global variables */
String haar_cascade_name = "haarcascade_dog_20.xml";
String lbp_cascade_name = "lbpcascade_dog_20.xml";
CascadeClassifier dog_cascade;
string window_name = "Dog Muzzle Detector";
string subtitle1="- Haar";
string subtitle2="- LBP";
float fps = 0.0;
int IsTest=0;
int No=1;
int HAAR=1;

void DetectAndDisplay(Mat mat);
void Test(const char *imgdir);

/** function Test */
void Test(const char *imgdir)
{   DIR *dir;
    struct dirent *ent;
    string image_filename;
    if ((dir = opendir (imgdir)) != NULL) {
        /* print all the files and directories within directory */
        while ((ent = readdir (dir)) != NULL) {
            if (strstr(ent->d_name,".jpg")!=NULL) {
                image_filename=ent->d_name;
                printf ("filename: %s\n", image_filename.c_str());
                char imagefile[80];
                sprintf(imagefile,"%s/%s",imgdir,image_filename.c_str());
                Mat img = imread(imagefile, 1);
                if( img.empty()) {
                    cout << "Couldn't load " <<imagefile << endl;
                }
                else {
                    DetectAndDisplay(img);
                }
            }
        }
    }
    free(ent);
    closedir(dir);
}

/** function main */
int main( int argc, const char * argv[] )
{   VideoCapture capture;
    Mat frame;
    for (int i=1;i<argc;i++)
    {   if (strcmp(argv[i],"-LBP")==0) HAAR=0;
    }
    if (HAAR==1)
    {   cout <<"CASCADE MODE: HAAR" <<endl;
        window_name+=subtitle1;
        if( !dog_cascade.load( haar_cascade_name ) ){ printf("--Error loading cascade classfier file:'%s' --\n",haar_cascade_name.c_str()); return -1; };
    }
    if (HAAR==0)
    {   cout <<"CASCADE MODE: LBP" <<endl;
        window_name+=subtitle2;
        if( !dog_cascade.load( lbp_cascade_name ) ){ printf("--Error loading cascade classfier file:'%s' --\n",lbp_cascade_name.c_str()); return -1; };
    }
     //-- 2. check arguments, open video camera if no arguments
    if (argc>2) //testing ./main -test testimagefoldername  e.g.: ./main -test /Usr/jw/Documents/testimage
    { if (strcmp(argv[1],"-test")==0)
       {   IsTest=1;
           Test(argv[2]);
           return 0;
       }
    }
    if (argc>=2) // A filename is followed,  "-LBP" included and tested below
    {  if (strcmp(argv[1],"-LBP")==0) goto LBP;
       frame = imread(argv[1], CV_LOAD_IMAGE_COLOR);
       if (!frame.data)  //not a image file,try to open as a video file
       {   capture=VideoCapture(argv[1]);
           if (capture.isOpened())
           {   printf("video frame width x height: %f x %f\n", capture.get(CV_CAP_PROP_FRAME_WIDTH),capture.get(CV_CAP_PROP_FRAME_HEIGHT));
               fps=0.0;
               do
               {   system_clock::time_point start = system_clock::now();
                   capture.read(frame);
                   //-- 3. Apply classifier to video frame
                   if( !frame.empty() )
                   {    //add fps to frame
                        char text[80];
                        sprintf(text,  "%2.1f", fps);
                        putText(frame, text, cvPoint(10,80), FONT_HERSHEY_PLAIN, 2, cvScalar(0,0,255),2,8);
                        DetectAndDisplay(frame);
                        system_clock::time_point end = system_clock::now();
                        float seconds = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
                        fps = 1000000 / seconds;
                   }
                   else
                   {   printf("Warning: -- No frame -- Break!\n");
                       break;
                   }
               } while (waitKey(30)<0);
               return 0;
           }
           else
           {   printf("Could not open file: %s as video file\n", argv[1]);
               return -1;
           }
           printf("Could not open file: %s as image file\n", argv[1]);
           return -1;
       }
       else
           {   printf("image size: %d x %d\n", frame.cols,frame.rows);
               DetectAndDisplay(frame);
               if (IsTest==0) waitKey(0);
           }
    }
    else   //Video Camera
    {   LBP:
        capture.open(0);
        Mat flipimg;
        if( capture.isOpened())
        {  capture.set(CV_CAP_PROP_FRAME_WIDTH, 640);
           capture.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
           printf("video frame width x height: %f x %f\n", capture.get(CV_CAP_PROP_FRAME_WIDTH),capture.get(CV_CAP_PROP_FRAME_HEIGHT));
           fps=0.0;
           do
           {   system_clock::time_point start = system_clock::now();
               capture.read(flipimg);
               //Apply the classifier to the frame
               if( !flipimg.empty() )
               {   //flip image
                   flip(flipimg,frame,1);
                   //add fps to frame
                   char text[80];
                   sprintf(text,  "%2.1f", fps);
                   putText(frame, text, cvPoint(10,80), FONT_HERSHEY_PLAIN, 2, cvScalar(0,0,255),2,8);
                   DetectAndDisplay(frame);
                   system_clock::time_point end = system_clock::now();
                   float seconds = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
                   fps = 1000000 / seconds;
               }
               else
               {   printf("Warning -- No frame -- Break!\n");
                   break;
               }
           } while (waitKey(30)<0);
        }
    }
    return 0;
 }

/** function detectAndDisplay */
void DetectAndDisplay( Mat frame )
{   std::vector<Rect> muzzles;
    Mat frame_gray;
    cvtColor( frame, frame_gray, CV_BGR2GRAY );
    equalizeHist( frame_gray, frame_gray );
    //Detect dog muzzle area
    dog_cascade.detectMultiScale( frame_gray, muzzles, 1.1, 120, 0|CV_HAAR_SCALE_IMAGE, Size(50, 50));
    for( size_t i = 0; i < muzzles.size(); i++ )
    {   Point center( muzzles[i].x + muzzles[i].width*0.5, muzzles[i].y + muzzles[i].height*0.5 );
        ellipse( frame, center, Size( muzzles[i].width*0.5, muzzles[i].height*0.5), 0, 0, 360, Scalar( 255, 255, 0 ), 4, 8, 0 );
    }
    char text[80];
    int dognumber = muzzles.size();
    if (dognumber>0) sprintf(text, "Found %d", dognumber);
    else sprintf(text,"0");
    putText(frame, text, cvPoint(10,30), FONT_HERSHEY_PLAIN, 2, cvScalar(0,0,255),2,8);
    if (IsTest==1)
    {   char filename[80];
        sprintf(filename,"Test%d.jpg",No);
        imwrite(filename,frame);
        No++;
    }
    else imshow(window_name,frame);
}
