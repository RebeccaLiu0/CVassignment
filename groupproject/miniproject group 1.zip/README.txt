Files included in the package:
1, Main.cpp
The mini project main program
2, haarcascade_dog_20.xml
Hear cascade classifier for dogs 20 stages
3, lbpcascade_dog_20.xml
LBP cascade classifier for dogs 20 stages
4, pos.vec
Training positive vector file 40x40, including 1813 image files
5, pos.txt
Positive image filename lists
6, neg.txt
Negative image filename lists
7, training.sh
Training script file
8, makefile
Script for make
9, README
This file